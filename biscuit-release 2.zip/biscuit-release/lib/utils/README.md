# utils
utility C code library
