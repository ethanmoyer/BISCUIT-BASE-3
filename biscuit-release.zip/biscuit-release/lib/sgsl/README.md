# sgsl
A lightweight subset of GNU scientific library
